
//Общая статитстика
export class Stat {
  id: number;
  title: string;
  completedTotal: number;
  unCompletedTotal: number;

}
