export enum OpenType {
  ADD,
  EDIT
}
