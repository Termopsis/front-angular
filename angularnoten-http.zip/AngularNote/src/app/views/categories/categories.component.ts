import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {Category} from "../../model/Category";
import {MatDialog} from '@angular/material';
import {EditCategoryComponent} from 'src/app/dialog/edit-category/edit-category.component';
import {OpenType} from 'src/app/dialog/OpenType';
import {CategorySearchValues} from 'src/app/data/dao/search/SearchObjects';

@Component({
    selector: 'app-categories',
    templateUrl: './categories.component.html',
    styleUrls: ['./categories.component.css']
})
export class CategoriesComponent implements OnInit {

  @Input('categories')
  set setCategories(categories: Category[]) {
    this.categories = categories;
  }

  @Input('selectedCategory')
  set setCategory(selectedCategory: Category) {
    this.selectedCategory = selectedCategory;
  }

  @Input('categorySearchValues')
  set setCategorySearchValues(categorySearchValues: CategorySearchValues) {
    this.categorySearchValues = categorySearchValues;
  }

  // используется для категории Все
  @Input('uncompletedCountForCategoryAll')
  set uncompletedCount(uncompletedCountForCategoryAll: number) {
    this.uncompletedCountForCategoryAll = uncompletedCountForCategoryAll;
  }

  @Input()
  selectedCategory: Category;



  @Output()
  selectCategory = new EventEmitter<Category>();

  @Output()
  updateCategory = new EventEmitter<Category>();

  @Output()
  deleteCategory = new EventEmitter<Category>();

  @Output()
  addCategory = new EventEmitter<string>();

  @Output()
  searchCategory = new EventEmitter<CategorySearchValues>();

  private categories: Category[];
  private indexMouseMove: number;
  private showEditIconCategory: boolean;
  private searchCategoryTitle: string;

  private filterTitle: string;
  private filterChanged: boolean;
  private categorySearchValues: CategorySearchValues;
  private uncompletedCountForCategoryAll: number;

  constructor(private dialog: MatDialog) {
  }

  // метод вызывается автоматически после инициализации компонента
  ngOnInit() {
  }

  private showTasksByCategory(category: Category) {

    if(this.selectedCategory === category){
      return;
    }

    this.selectedCategory = category;
    this.selectCategory.emit(this.selectedCategory);
  }

  private showEditIcon(show: boolean, index: number){
    this.indexMouseMove = index;
    this.showEditIconCategory = show;
  }

  private openEditCategoryDialog(category: Category){
    const dialogRef = this.dialog.open(EditCategoryComponent,{
      data: [category.title, 'Редактирование категории', OpenType.EDIT],
      autoFocus: false,
      width: '400px'
    });

    dialogRef.afterClosed().subscribe(result => {

      if (result === 'delete'){
        this.deleteCategory.emit(category);
        return;
      }

      if (result as string) {
        category.title = result as string;

        this.updateCategory.emit(category);
        return;
      }
    });
  }

  public onAddCategory(){

    const dialogRef = this.dialog.open(EditCategoryComponent,{
      data: ['','Добавление категории',OpenType.ADD],
      autoFocus: false,
      width: '400px'
    });

    dialogRef.afterClosed().subscribe(result =>{
      if (result){
        this.addCategory.emit(result as string);
      }
    });
  }

  public search(){
    this.filterChanged = false; // сбросить

    if (!this.categorySearchValues) { // если объект с параметрами поиска непустой
      return;
    }

    this.categorySearchValues.title = this.filterTitle;
    this.searchCategory.emit(this.categorySearchValues);
  }

  clearAndSearch(){
    this.filterChanged = null;
    this.search();
  }

  checkFilterChanged() {

    this.filterChanged = false;
    // console.log(this.filterTitle);
    // console.log(this.categorySearchValues.title);
    if (this.filterTitle !== this.categorySearchValues.title){
      this.filterChanged = true;
    }

    return this.filterChanged;

  }

}
